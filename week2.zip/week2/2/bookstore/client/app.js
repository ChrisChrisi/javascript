"use strict";

var makeSTag = function (content, tag) {
    return '<' +tag
    + '>'
    + content
    + '</'
    + tag
    + '>';
};
var addBook = function (book) {
    var content = '<div id="book.isbn" class="col-xs-4 td-bottom book">'
        + makeSTag(book.title, "h3")
        + '<img src="'
        + book.image_url
        + '">'
        + makeSTag("Averege rating: " + book.average_rating, "p")
        + makeSTag("ISBN: " + book.isbn, "p")
        + '<button id ="description-button" class = "btn btn-info" > Read description </button >'
        + '<div id="description" class = "hidden"> "'+ book.description+'"</div>'
        + '<button id="cart_button" class="btn btn-success">Add to Cart</button>'
        + '</div > ';
    return content;
};

var loadBooks = function(allBooks){
    var rowBegin = '<div class="row">';
    var rowEnd = '</div>';
    var allItems = "";
  allBooks.forEach(function(book, i){

          allItems += addBook(book);

  });
  return allItems;
};

$(document).ready(function(){
    $.getJSON('http://localhost:3000/books', function (books, textStatus) {
        $("#shelf").append(loadBooks(books));
    });

    $("#shelf").on("click", "button[id='description-button']",function(){
       var description = $(this).parent().children("#description");
        description.toggleClass( "hidden" );
    })

    $("#shelf").on("click", "button[id='cart_button']",function(){
       alert('cart!');
    })
});
