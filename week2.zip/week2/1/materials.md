# Materials for week 2

## Object Oriented JavaScript

We are going to start working with OOP JavaScript! There are few very different things from the rest of the OOP world (For example, there are no classes)

A good start is this reference - https://developer.mozilla.org/en-US/docs/Web/JavaScript/Introduction_to_Object-Oriented_JavaScript
